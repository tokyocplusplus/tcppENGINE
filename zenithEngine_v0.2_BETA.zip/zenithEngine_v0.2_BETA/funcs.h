#include<GLFW/glfw3.h>

GLfloat vertices[] = {
    -0.6f, 0.6f, 0.0f, /*0*/ 1.0f, 1.0f, 1.0f, /*COLOR*/ 0.0f, 1.0f, /*TEXTURE COORDS*/
     0.6f, 0.6f, 0.0f, /*1*/ 1.0f, 1.0f, 1.0f, /*COLOR*/ 1.0f, 1.0f, /*TEXTURE COORDS*/
     0.6f,-0.6f, 0.0f, /*2*/ 1.0f, 1.0f, 1.0f, /*COLOR*/ 1.0f, 0.0f, /*TEXTURE COORDS*/ 
    -0.6f,-0.6f, 0.0f, /*3*/ 1.0f, 1.0f, 1.0f, /*COLOR*/ 0.0f, 0.0f, /*TEXTURE COORDS*/
};

GLuint indices[] = {
    0,1,2,
    0,3,2,
};

GLfloat lightVertices[] = {
    // Positions          
    -0.1f, -0.1f, -0.1f,  // Front bottom left
     0.1f, -0.1f, -0.1f,  // Front bottom right
     0.1f,  0.1f, -0.1f,  // Back bottom right
    -0.1f,  0.1f, -0.1f,  // Back bottom left
    -0.1f, -0.1f,  0.1f,  // Front top left
     0.1f, -0.1f,  0.1f,  // Front top right
     0.1f,  0.1f,  0.1f,  // Back top right
    -0.1f,  0.1f,  0.1f   // Back top left
};

// Indices for drawing the cube (6 faces, 2 triangles per face, 3 vertices per triangle)
GLuint lightIndices[] = {
    0, 1, 2, 2, 3, 0,   // Front face
    4, 5, 6, 6, 7, 4,   // Back face
    4, 5, 1, 1, 0, 4,   // Bottom face
    7, 6, 2, 2, 3, 7,   // Top face
    4, 7, 3, 3, 0, 4,   // Left face
    5, 6, 2, 2, 1, 5    // Right face
};

// variables for window
const uint16_t windowWidth = 1280;
const uint16_t windowHeight = 720;
const char* windowTitle = "";

const char* vertSource = R"(
#version 460 core

layout (location = 0) in vec3 vPos;
layout (location = 1) in vec3 vColor;
layout (location = 2) in vec2 vTexCoord;

out vec3 vertColors;
out vec2 TexCoord;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main() {
    gl_Position = projection * view * model * vec4(vPos, 1.0f);
    vertColors = vColor;
    TexCoord = vec2(vTexCoord.x, vTexCoord.y);
}
)";

const char* fragSource = R"(
#version 460 core

out vec4 fColor;
in vec3 vertColors;
in vec2 TexCoord;

uniform sampler2D texture1;

void main() {
    //fColor = texture(texture1, TexCoord);
    //COLORED VER
    fColor = texture(texture1, TexCoord) * vec4(vertColors, 1.0f);
    //UNTEXTURED
    //fColor = vec4(vertColors, 1.0f);
}
)";

const char* vertexLightShaderSource = R"(
#version 330 core

layout (location = 0) in vec3 aPos;

uniform mat4 model;
uniform mat4 projection;
uniform mat4 view;

void main()
{
	gl_Position = projection * view * model * vec4(aPos, 1.0f);
}
)";

const char* fragmentLightShaderSource = R"(
#version 330 core

out vec4 FragColor;

uniform vec4 lightColor;

void main() {
    FragColor = vec4(1,0,1,1);
}
)";

void init(int versionMajor, int versionMinor) {
    glfwInit();
    glfwWindowHint(GLFW_CLIENT_API, GLFW_OPENGL_API);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, versionMajor);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, versionMinor);
}

void clear(float R, float G, float B, float A) {
    glClearColor(R,G,B,A);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}